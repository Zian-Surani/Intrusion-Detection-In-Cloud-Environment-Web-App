# sentinelx_demo_app.py
import streamlit as st
import re, joblib, json, os, time
from typing import List, Tuple, Dict, Any
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import requests

try:
    import shap
    HAS_SHAP = True
except Exception:
    HAS_SHAP = False

# CONFIG: default model file (user should replace with actual artifact filename)
MODEL_PATH = "artifacts/mlp_fixed_TIMESTAMP.joblib"  # replace with your actual model filename

st.set_page_config(page_title="Sentinel X - Demo IDS", layout="wide")

DFA_RULES = [
    ("many_4xx", re.compile(r'\" \b4\d{2}\b'), "Multiple 4xx responses (client errors)"),
    ("many_5xx", re.compile(r'\" \b5\d{2}\b'), "Multiple 5xx responses (server errors)"),
    ("post_burst", re.compile(r'\bPOST\b.*'), "Burst of POST requests"),
    ("rapid_gets", re.compile(r'\bGET\b.*'), "Many GET requests (potential scraping)"),
    ("small_responses", re.compile(r'Content-Length:\s*([0-9]{1,3})\b'), "Many small responses")
]

def dfa_check_lines(lines: List[str], min_matches:int=3) -> Tuple[bool, dict, List[int]]:
    for name, pat, desc in DFA_RULES:
        matches = []
        for i, ln in enumerate(lines):
            if pat.search(ln):
                matches.append(i)
        if len(matches) >= min_matches:
            return True, {"name": name, "desc": desc}, matches
    return False, {}, []

def extract_features_from_lines(lines: List[str]) -> Tuple[Dict[str,Any], List[float]]:
    count = len(lines)
    errors = 0
    total_dst_bytes = 0
    total_src_bytes = 0
    srv_count = count
    same_srv_rate = 0.5
    dst_host_count = max(1, min(255, count // 2))
    dst_host_srv_count = max(1, min(255, count // 3))
    protocol_type = "tcp"
    service = "http"
    flag = "SF"
    durations = []
    status_re = re.compile(r'\" (\d{3})\b')
    bytes_re = re.compile(r'Content-Length:\s*(\d+)', flags=re.IGNORECASE)
    for ln in lines:
        m = status_re.search(ln)
        if m:
            code = int(m.group(1))
            if 400 <= code < 600:
                errors += 1
        b = 0
        m2 = bytes_re.search(ln)
        if m2:
            try:
                b = int(m2.group(1))
            except:
                b = 0
        else:
            m3 = re.search(r'\b(\d{2,6})\b', ln)
            if m3:
                try:
                    val = int(m3.group(1))
                    if val > 100:
                        b = val
                except:
                    b = 0
        total_dst_bytes += b
        durations.append(0.1)
    error_rate = errors / max(1, count)
    avg_dst_bytes = total_dst_bytes / max(1, count)
    avg_src_bytes = total_src_bytes / max(1, count)
    duration = sum(durations)
    feat = {
        "duration": float(duration),
        "protocol_type": protocol_type,
        "service": service,
        "flag": flag,
        "src_bytes": float(avg_src_bytes),
        "dst_bytes": float(avg_dst_bytes),
        "count": int(count),
        "srv_count": int(srv_count),
        "same_srv_rate": float(same_srv_rate),
        "dst_host_count": int(dst_host_count),
        "dst_host_srv_count": int(dst_host_srv_count)
    }
    line_scores = []
    for ln in lines:
        score = 0.0
        if re.search(r'\" (\d{3})\b', ln):
            code = int(re.search(r'\" (\d{3})\b', ln).group(1))
            if 500 <= code < 600:
                score += 0.7
            elif 400 <= code < 500:
                score += 0.5
        if re.search(r'POST', ln):
            score += 0.3
        if re.search(r'Content-Length:\s*([0-9]{1,3})', ln, flags=re.I):
            score += 0.1
        line_scores.append(min(1.0, score))
    return feat, line_scores

def get_pos_proba_from_pipeline(pipe, feature_df: pd.DataFrame):
    if hasattr(pipe, "predict_proba"):
        probs = pipe.predict_proba(feature_df)
        if probs.ndim == 1 or probs.shape[1] == 1:
            return pipe.predict(feature_df).astype(float)
        classes = getattr(pipe, "classes_", None)
        if classes is not None:
            for i, cls in enumerate(classes):
                if str(cls) in ("1","True","true"):
                    return probs[:, i]
        return probs[:, -1]
    else:
        return pipe.predict(feature_df).astype(float)

st.title("Sentinel X — Demo IDS")
st.markdown("Hybrid DFA + ANN demo. HTTP-only demo mode. Paste logs or provide HTTP URL (GET).")

col1, col2 = st.columns([1,2])

with col1:
    mode = st.radio("Input mode", ("Paste logs", "Enter HTTP URL (demo)"))
    st.markdown("**Model selection / upload**")
    uploaded_model = st.file_uploader("Upload sklearn .joblib model (optional)", type=["joblib"])
    if uploaded_model is not None:
        model_path_temp = os.path.join("artifacts", f"uploaded_model_{int(time.time())}.joblib")
        with open(model_path_temp, "wb") as f:
            f.write(uploaded_model.getbuffer())
        MODEL_PATH = model_path_temp
        st.success(f"Uploaded model saved to {MODEL_PATH}")
    elif MODEL_PATH is None:
        st.warning("No default model path set. Upload a joblib model or set MODEL_PATH in the script.")
    else:
        st.info(f"Using model: {MODEL_PATH}")
    ann_threshold = st.slider("ANN 'suspicious' threshold", 0.0, 1.0, 0.7, 0.05)
    high_conf = st.slider("ANN 'high confidence' threshold", 0.0, 1.0, 0.85, 0.01)
    st.markdown("---")
    st.markdown("DFA rules (demo):")
    for nm, _, desc in DFA_RULES:
        st.write(f"- **{nm}**: {desc}")

with col2:
    if mode == "Paste logs":
        raw = st.text_area("Paste HTTP-style logs / request lines (one per line). Example lines:\nGET /index.html HTTP/1.1\" 200 Content-Length: 1024", height=240)
        lines = [l.strip() for l in raw.splitlines() if l.strip()]
    else:
        url = st.text_input("Enter an HTTP URL (http://...)")
        lines = []
        if st.button("Fetch URL") and url:
            try:
                if not url.lower().startswith("http://"):
                    st.warning("Only HTTP (not HTTPS) is allowed in demo mode. If you want HTTPS you must use Playwright or pre-captured HAR.")
                resp = requests.get(url, timeout=10)
                status = resp.status_code
                content_length = resp.headers.get("Content-Length") or len(resp.content)
                line = f"GET {url} HTTP/1.1\" {status} Content-Length: {content_length}"
                st.success(f"Fetched {url} - status {status}")
                lines = [line]
                st.code(line)
            except Exception as e:
                st.error(f"Failed to fetch URL: {e}")
                lines = []
    if not lines:
        st.info("No input lines yet. Paste logs or fetch an HTTP URL to analyze.")
    else:
        st.subheader("Input preview")
        for i, ln in enumerate(lines[:200]):
            st.text(f"{i+1}: {ln}")

if st.button("Run IDS Analysis"):
    if not lines:
        st.error("No input provided.")
    else:
        matched, rule_detail, match_indices = dfa_check_lines(lines, min_matches=1)
        st.markdown("## Results")
        if matched:
            st.success(f"DFA matched rule: **{rule_detail['name']}** — {rule_detail['desc']}")
            st.write("Matching line indices:", match_indices)
        else:
            st.info("No DFA rule matched.")
        feat_dict, line_scores = extract_features_from_lines(lines)
        st.write("### Extracted features (approx):")
        st.json(feat_dict)
        feature_df = pd.DataFrame([feat_dict])
        model = None
        if MODEL_PATH:
            try:
                model = joblib.load(MODEL_PATH)
            except Exception as e:
                st.error(f"Failed to load model at {MODEL_PATH}: {e}")
                model = None
        ann_used = False
        ann_prob = None
        justification = ""
        highlighted_lines = []
        if matched:
            verdict = "ATTACK (DFA)"
            severity_score = 0.9
            justification = f"DFA rule `{rule_detail['name']}` matched: {rule_detail['desc']}. Matched lines: {match_indices}"
            highlighted_lines = match_indices
        else:
            if model is None:
                verdict = "UNKNOWN (no model)"
                justification = "No ANN model available; DFA did not match."
            else:
                try:
                    proba = get_pos_proba_from_pipeline(model, feature_df)[0]
                    ann_prob = float(proba)
                    ann_used = True
                    if ann_prob >= high_conf:
                        verdict = f"ATTACK (ANN prob={ann_prob:.2f})"
                        severity_score = ann_prob
                        justification = f"ANN model predicted high probability of attack ({ann_prob:.2f})."
                    elif ann_prob >= ann_threshold:
                        verdict = f"SUSPICIOUS (ANN prob={ann_prob:.2f})"
                        severity_score = ann_prob
                        justification = f"ANN flagged suspicious traffic (prob={ann_prob:.2f})."
                    else:
                        verdict = f"NORMAL (ANN prob={ann_prob:.2f})"
                        severity_score = ann_prob
                        justification = f"ANN predicted normal traffic (prob={ann_prob:.2f})."
                except Exception as e:
                    verdict = "ERROR (model inference)"
                    justification = f"Model inference failed: {e}"
        st.markdown("### Final verdict")
        if "ATTACK" in verdict:
            st.error(verdict)
        elif "SUSPICIOUS" in verdict:
            st.warning(verdict)
        else:
            st.success(verdict)
        st.write("Justification:", justification)
        st.markdown("### Highlighted / suspicious lines (heatmap and details)")
        df_lines = pd.DataFrame({"line": lines, "score": line_scores})
        if matched:
            for idx in match_indices:
                if 0 <= idx < len(df_lines):
                    df_lines.loc[idx, "score"] = max(df_lines.loc[idx, "score"], 0.9)
        if ann_used and ann_prob is not None and ann_prob > ann_threshold:
            for i, ln in enumerate(lines):
                if re.search(r'(4\d{2}|5\d{2}|POST|login|auth|passwd|admin|wp-login)', ln, flags=re.I):
                    df_lines.loc[i, "score"] = max(df_lines.loc[i, "score"], min(0.8, ann_prob))
        for idx, row in df_lines.iterrows():
            score = row["score"]
            color = "white"
            if score >= 0.8:
                color = "#ffcccc"
            elif score >= 0.5:
                color = "#fff2cc"
            elif score >= 0.2:
                color = "#e6f7ff"
            st.markdown(f"<div style='background:{color};padding:6px;border-radius:4px'>{idx+1}: {row['line']} <b> score={score:.2f}</b></div>", unsafe_allow_html=True)
        fig, ax = plt.subplots(figsize=(8, max(1, len(df_lines)*0.2)))
        ax.imshow(np.array(df_lines["score"].values).reshape(1, -1), aspect='auto', cmap='Reds')
        ax.set_yticks([])
        ax.set_xticks(range(len(df_lines)))
        ax.set_xticklabels([str(i+1) for i in range(len(df_lines))], rotation=90)
        ax.set_title("Severity heatmap (per-line)")
        st.pyplot(fig)
        st.markdown("### Explanation / feature importance")
        if model is None:
            st.info("No model loaded → cannot show model explanation.")
        else:
            try:
                if HAS_SHAP:
                    try:
                        final_est = model
                        if hasattr(model, "named_steps"):
                            final_est = model.named_steps[list(model.named_steps.keys())[-1]]
                            preproc = model.named_steps.get("preproc", None)
                            X_pre = preproc.transform(feature_df) if preproc is not None else feature_df
                        else:
                            X_pre = feature_df
                        explainer = shap.Explainer(final_est, X_pre, feature_names=(preproc.get_feature_names_out() if preproc is not None else None))
                        shap_values = explainer(X_pre)
                        st.pyplot(shap.plots.bar(shap_values, show=False))
                    except Exception as e:
                        st.warning("SHAP explanation failed: " + str(e))
                        raise
                else:
                    if hasattr(model, "named_steps") and "clf" in model.named_steps and hasattr(model.named_steps["clf"], "feature_importances_"):
                        clf = model.named_steps["clf"]
                        preproc = model.named_steps.get("preproc", None)
                        try:
                            num_cols = preproc.transformers_[0][2]
                            cat_cols = preproc.transformers_[1][2]
                            ohe = preproc.named_transformers_["cat"]
                            cat_names = list(ohe.get_feature_names_out(cat_cols))
                            feat_names = list(num_cols) + cat_names
                        except Exception:
                            feat_names = [f"f{i}" for i in range(len(clf.feature_importances_))]
                        imps = clf.feature_importances_
                        imp_df = pd.Series(imps, index=feat_names).sort_values(ascending=False).head(10)
                        st.bar_chart(imp_df)
                    else:
                        st.info("Model does not expose feature importances. For deeper explainability, install shap or use a tree-based model.")
            except Exception as e:
                st.error(f"Explanation generation failed: {e}")
        out = {
            "verdict": verdict,
            "justification": justification,
            "ann_prob": ann_prob,
            "dfa_match": matched,
            "dfa_rule": rule_detail,
            "highlighted_lines": df_lines.to_dict(orient="records")
        }
        st.download_button("Download results (JSON)", json.dumps(out, indent=2), file_name="sentinelx_result.json")
